/**
 * Copyright (c) 2014 Microsoft Open Technologies, Inc.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABILITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 *    Microsoft would like to thank the following companies for their review and
 *    assistance with these files: Intel Corporation, Mellanox Technologies Ltd,
 *    Dell Products, L.P., Facebook, Inc., Marvell International Ltd.
 *
 * @file    saipolicerextensions.h
 *
 * @brief   This module defines SAI QOS Policer interface extensions
 */

#ifndef __SAIPOLICEREXTENSIONS_H_
#define __SAIPOLICEREXTENSIONS_H_

#include <sai.h>

/**
 * @brief Enum defining mode of the policer object extensions
 *
 * @flags free
 */
typedef enum _sai_policer_mode_extensions_t
{
    SAI_POLICER_MODE_EXTENSIONS_START = SAI_POLICER_MODE_STORM_CONTROL,

    /** RFC 4115, Two Rate Three color marker, CIR, CBS, PIR and PBS, G, Y and R */
    SAI_POLICER_MODE_ENHANCED_TR_TCM,

    SAI_POLICER_MODE_EXTENSIONS_END

} sai_policer_mode_extensions_t;

/**
 * @brief Enum defining Policer Attributes extensions
 *
 * @flags free
 */
typedef enum _sai_policer_attr_extensions_t
{
    SAI_POLICER_ATTR_EXTENSIONS_RANGE_START = SAI_POLICER_ATTR_EXTENSIONS_RANGE_BASE,

    /**
     * @brief Enable/disable counter
     *
     * Default disabled. Modify list needs full new set.
     *
     * @type sai_s32_list_t
     * @flags CREATE_AND_SET
     * @default empty
     */
    SAI_POLICER_ATTR_ENABLE_COUNTER_LIST = SAI_POLICER_ATTR_EXTENSIONS_RANGE_START,

    SAI_POLICER_ATTR_EXTENSIONS_RANGE_END

} sai_policer_attr_extensions_t;

#endif /** __SAIPOLICEREXTENSIONS_H_ */
