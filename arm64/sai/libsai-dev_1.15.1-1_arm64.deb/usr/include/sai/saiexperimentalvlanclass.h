/**
 * Copyright (c) 2014 Microsoft Open Technologies, Inc.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABILITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 *    Microsoft would like to thank the following companies for their review and
 *    assistance with these files: Intel Corporation, Mellanox Technologies Ltd,
 *    Dell Products, L.P., Facebook, Inc., Marvell International Ltd.
 *
 * @file    saiexperimentalvlanclass.h
 *
 * @brief   This module defines SAI VLAN Class
 */

#if !defined (__SAIEXPERIMENTALVLANCLASS_H_)
#define __SAIEXPERIMENTALVLANCLASS_H_

#include <saitypes.h>

/**
 * @defgroup SAIVLANCLASS SAI - VLAN CLASS specific API definitions
 *
 * @{
 */

/**
 * @brief Enum defining attributes for VLAN Class.
 */
typedef enum _sai_vlan_class_attr_t
{
    /**
     * @brief Start of attributes
     */
    SAI_VLAN_CLASS_ATTR_START,

    /**
     * @brief MAC Address
     *
     * @type sai_mac_t
     * @flags MANDATORY_ON_CREATE |CREATE_ONLY
     */
    SAI_VLAN_CLASS_ATTR_MAC_ADDRESS = SAI_VLAN_CLASS_ATTR_START,

    /**
     * @brief Associated Vlan Id
     *
     * @type sai_object_id_t
     * @flags CREATE_ONLY
     * @objects SAI_OBJECT_TYPE_VLAN
     * @allownull true
     * @default SAI_NULL_OBJECT_ID
     */
    SAI_VLAN_CLASS_ATTR_VLAN_ID,

    /**
     * @brief User based Meta Data
     *
     * @type sai_uint32_t
     * @flags CREATE_ONLY
     * @default 0
     */
    SAI_VLAN_CLASS_ATTR_META_DATA,

    /**
     * @brief End of attributes
     */
    SAI_VLAN_CLASS_ATTR_END,

    /** Custom range base value */
    SAI_VLAN_CLASS_ATTR_CUSTOM_RANGE_START = 0x10000000,

    /** End of custom range base */
    SAI_VLAN_CLASS_ATTR_CUSTOM_RANGE_END

} sai_vlan_class_attr_t;

/**
 * @brief Create VLAN Class
 *
 * @param[out] vlan_class_id Vlan class id
 * @param[in] switch_id Switch id
 * @param[in] attr_count Number of attributes
 * @param[in] attr_list Array of attributes
 *
 * @return #SAI_STATUS_SUCCESS on success, failure status code on error
 */
typedef sai_status_t (*sai_create_vlan_class_fn)(
        _Out_ sai_object_id_t *vlan_class_id,
        _In_ sai_object_id_t switch_id,
        _In_ uint32_t attr_count,
        _In_ const sai_attribute_t *attr_list);

/**
 * @brief Remove VLAN Class
 *
 * @param[in] vlan_class_id Vlan class id
 *
 * @return #SAI_STATUS_SUCCESS on success, failure status code on error
 */
typedef sai_status_t (*sai_remove_vlan_class_fn)(
        _In_ sai_object_id_t vlan_class_id);

/**
 * @brief Set VLAN Class attribute
 *
 * @param[in] vlan_class_id Vlan class id
 * @param[in] attr Attributes
 *
 * @return #SAI_STATUS_SUCCESS on success, failure status code on error
 */
typedef sai_status_t (*sai_set_vlan_class_attribute_fn)(
        _In_ sai_object_id_t vlan_class_id,
        _In_ const sai_attribute_t *attr);

/**
 * @brief Get VLAN Class attribute
 *
 * @param[in] vlan_class_id Vlan class id
 * @param[in] attr_count Number of attributes
 * @param[inout] attr_list Array of attributes
 *
 * @return #SAI_STATUS_SUCCESS on success, failure status code on error
 */
typedef sai_status_t (*sai_get_vlan_class_attribute_fn)(
        _In_ sai_object_id_t vlan_class_id,
        _In_ uint32_t attr_count,
        _Inout_ sai_attribute_t *attr_list);

/**
 * @brief VLAN Class methods table retrieved with sai_api_query()
 */
typedef struct _sai_vlan_class_api_t
{
    sai_create_vlan_class_fn               create_vlan_class;
    sai_remove_vlan_class_fn               remove_vlan_class;
    sai_set_vlan_class_attribute_fn        set_vlan_class_attribute;
    sai_get_vlan_class_attribute_fn        get_vlan_class_attribute;

} sai_vlan_class_api_t;

/**
 * @}
 */
#endif /** __SAIEXPERIMENTALVLANCLASS_H_ */
