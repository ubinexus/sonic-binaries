/**
 * Copyright (c) 2014 Microsoft Open Technologies, Inc.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABILITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 *    Microsoft would like to thank the following companies for their review and
 *    assistance with these files: Intel Corporation, Mellanox Technologies Ltd,
 *    Dell Products, L.P., Facebook, Inc., Marvell International Ltd.
 *
 * @file    saitunnelextensions.h
 *
 * @brief   This module defines SAI Tunnel interface extensions
 */

#ifndef __SAITUNNELEXTENSIONS_H_
#define __SAITUNNELEXTENSIONS_H_

#include <sai.h>

/**
 * @brief Defines tunnel type extensions
 *
 * @flags free
 */
typedef enum _sai_tunnel_type_extensions_t
{
    SAI_TUNNEL_TYPE_EXTENSIONS_START = SAI_TUNNEL_TYPE_VXLAN_UDP_ESP,

    SAI_TUNNEL_TYPE_MPLS_L2,

    SAI_TUNNEL_TYPE_EXTENSIONS_END

} sai_tunnel_type_extensions_t;

/**
 * @brief Defines tunnel EXP mode
 */
typedef enum _sai_tunnel_exp_mode_t
{
    /**
     * @brief The uniform model
     *
     * Where the traffic class and drop precedence is preserved end-to-end by
     * either copying into the outer header on encapsulation or applying QOS map
     * and either copying from the outer header or applying QOS map on decapsulation.
     * This is applicable for inner IP or MPLS packets.
     */
    SAI_TUNNEL_EXP_MODE_UNIFORM_MODEL,

    /**
     * @brief The pipe model
     *
     * Where the outer header is independent of that in the inner header so
     * it hides the EXP field of the inner header from any interaction
     * with nodes along the tunnel.
     *
     * EXP field is user-defined for outer header on encapsulation. EXP
     * field of inner header remains the same on decapsulation.
     */
    SAI_TUNNEL_EXP_MODE_PIPE_MODEL

} sai_tunnel_exp_mode_t;

/**
 * @brief Defines tunnel MPLS PW mode
 */
typedef enum _sai_tunnel_mpls_pw_mode_t
{
    /**
     * @brief MPLS PW Tagged mode
     */
    SAI_TUNNEL_MPLS_PW_MODE_TAGGED,

    /**
     * @brief MPLS PW Raw mode
     */
    SAI_TUNNEL_MPLS_PW_MODE_RAW,
} sai_tunnel_mpls_pw_mode_t;

/**
 * @brief Defines tunnel attributes extensions
 *
 * @flags free
 */
typedef enum _sai_tunnel_attr_extensions_t
{
    SAI_TUNNEL_ATTR_EXTENSIONS_RANGE_START = SAI_TUNNEL_ATTR_EXTENSIONS_RANGE_BASE,

    /**
     * @brief Tunnel associated Nexthop ID for encap.
     *
     * @type sai_object_id_t
     * @flags READ_ONLY
     * @objects SAI_OBJECT_TYPE_NEXT_HOP, SAI_OBJECT_TYPE_NEXT_HOP_GROUP
     */
    SAI_TUNNEL_ATTR_ENCAP_NEXTHOP_ID = SAI_TUNNEL_ATTR_EXTENSIONS_RANGE_START,

    /**
     * @brief MPLS Virtual Private Network Tunnel mode for decap.
     *
     * @type sai_tunnel_mpls_pw_mode_t
     * @flags MANDATORY_ON_CREATE | CREATE_ONLY
     * @condition SAI_TUNNEL_ATTR_TYPE == SAI_TUNNEL_TYPE_MPLS_L2
     */
    SAI_TUNNEL_ATTR_DECAP_MPLS_PW_MODE,

    /**
     * @brief MPLS Virtual Private Network Tunnel with Control Word for decap.
     *
     * @type bool
     * @flags CREATE_AND_SET
     * @default false
     * @validonly SAI_TUNNEL_ATTR_TYPE == SAI_TUNNEL_TYPE_MPLS_L2
     */
    SAI_TUNNEL_ATTR_DECAP_MPLS_PW_WITH_CW,

    /**
     * @brief MPLS Virtual Private Network Tunnel mode for encap.
     *
     * @type sai_tunnel_mpls_pw_mode_t
     * @flags MANDATORY_ON_CREATE | CREATE_ONLY
     * @condition SAI_TUNNEL_ATTR_TYPE == SAI_TUNNEL_TYPE_MPLS_L2
     */
    SAI_TUNNEL_ATTR_ENCAP_MPLS_PW_MODE,

    /**
     * @brief MPLS Virtual Private Network Tunnel with Control Word for encap.
     *
     * @type bool
     * @flags CREATE_AND_SET
     * @default false
     * @validonly SAI_TUNNEL_ATTR_TYPE == SAI_TUNNEL_TYPE_MPLS_L2
     */
    SAI_TUNNEL_ATTR_ENCAP_MPLS_PW_WITH_CW,

    /**
     * @brief Tunnel encap MPLS Pseudo wire tagged mode vlan
     *
     * Valid when SAI_TUNNEL_ATTR_TYPE == SAI_TUNNEL_TYPE_MPLS_L2 and SAI_TUNNEL_ATTR_DECAP_MPLS_PW_MODE == SAI_TUNNEL_MPLS_PW_MODE_TAGGED
     *
     * @type sai_uint16_t
     * @flags CREATE_AND_SET
     * @isvlan false
     * @default 0
     */
    SAI_TUNNEL_ATTR_ENCAP_MPLS_PW_TAGGED_VLAN,

    /**
     * @brief MPLS Virtual Private Network Tunnel Ethernet Segment Identifier Label Enable.
     *
     * @type bool
     * @flags CREATE_AND_SET
     * @default false
     * @validonly SAI_TUNNEL_ATTR_TYPE == SAI_TUNNEL_TYPE_MPLS_L2
     */
    SAI_TUNNEL_ATTR_DECAP_ESI_LABEL_VALID,

    /**
     * @brief MPLS Virtual Private Network Tunnel Ethernet Segment Identifier Label Enable.
     *
     * @type bool
     * @flags CREATE_AND_SET
     * @default false
     * @validonly SAI_TUNNEL_ATTR_TYPE == SAI_TUNNEL_TYPE_MPLS_L2
     */
    SAI_TUNNEL_ATTR_ENCAP_ESI_LABEL_VALID,

    /**
     * @brief Tunnel EXP mode (pipe or uniform model)
     *
     * Default SAI_TUNNEL_EXP_MODE_UNIFORM_MODEL
     *
     * @type sai_tunnel_exp_mode_t
     * @flags CREATE_AND_SET
     * @default SAI_TUNNEL_EXP_MODE_UNIFORM_MODEL
     * @validonly SAI_TUNNEL_ATTR_TYPE == SAI_TUNNEL_TYPE_MPLS
     */
    SAI_TUNNEL_ATTR_DECAP_EXP_MODE,

    /**
     * @brief Tunnel EXP mode (pipe or uniform model)
     *
     * @type sai_tunnel_exp_mode_t
     * @flags CREATE_AND_SET
     * @default SAI_TUNNEL_EXP_MODE_UNIFORM_MODEL
     * @validonly SAI_TUNNEL_ATTR_TYPE == SAI_TUNNEL_TYPE_MPLS
     */
    SAI_TUNNEL_ATTR_ENCAP_EXP_MODE,

    /**
     * @brief Tunnel EXP value (3 bits)
     *
     * Valid when SAI_TUNNEL_ATTR_ENCAP_EXP_MODE == SAI_TUNNEL_EXP_MODE_PIPE_MODEL and SAI_TUNNEL_ATTR_TYPE == SAI_TUNNEL_TYPE_MPLS
     *
     * @type sai_uint8_t
     * @flags CREATE_ONLY
     * @default 0
     */
    SAI_TUNNEL_ATTR_ENCAP_EXP_VAL,

    /**
     * @brief Tunnel use outer parser info for ACL lookup
     *
     * @type bool
     * @flags CREATE_AND_SET
     * @default false
     */
    SAI_TUNNEL_ATTR_DECAP_ACL_USE_OUTER_HDR_INFO,

    /**
     * @brief MPLS Virtual Private Network Tunnel Split-Horizon Enable for flooding or multicast.
     *
     * @type bool
     * @flags CREATE_AND_SET
     * @default true
     * @validonly SAI_TUNNEL_ATTR_TYPE == SAI_TUNNEL_TYPE_MPLS_L2
     */
    SAI_TUNNEL_ATTR_DECAP_SPLIT_HORIZON_ENABLE,

    /**
     * @brief The decryption secure channel of this VXLAN tunnel.
     *
     * @type sai_object_id_t
     * @flags CREATE_AND_SET
     * @objects SAI_OBJECT_TYPE_MACSEC_SC
     * @allownull true
     * @default SAI_NULL_OBJECT_ID
     * @validonly SAI_TUNNEL_ATTR_TYPE == SAI_TUNNEL_TYPE_VXLAN
     */
    SAI_TUNNEL_ATTR_CLOUDSEC_DECRYPT_SC,

    /**
     * @brief The encryption secure channel of this VXLAN tunnel.
     *
     * @type sai_object_id_t
     * @flags CREATE_AND_SET
     * @objects SAI_OBJECT_TYPE_MACSEC_SC
     * @allownull true
     * @default SAI_NULL_OBJECT_ID
     * @validonly SAI_TUNNEL_ATTR_TYPE == SAI_TUNNEL_TYPE_VXLAN
     */
    SAI_TUNNEL_ATTR_CLOUDSEC_ENCRYPT_SC,

    SAI_TUNNEL_ATTR_EXTENSIONS_RANGE_END

} sai_tunnel_attr_extensions_t;

#endif /** __SAITUNNELEXTENSIONS_H_ */

