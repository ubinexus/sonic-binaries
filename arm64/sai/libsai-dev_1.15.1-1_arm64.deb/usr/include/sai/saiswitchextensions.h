/**
 * Copyright (c) 2018 Microsoft Open Technologies, Inc.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABILITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 *    Microsoft would like to thank the following companies for their review and
 *    assistance with these files: Intel Corporation, Mellanox Technologies Ltd,
 *    Dell Products, L.P., Facebook, Inc., Marvell International Ltd.
 *
 * @file    saiswitchextensions.h
 *
 * @brief   This module defines switch extensions of the Switch Abstraction Interface (SAI)
 */

#ifndef __SAISWITCHEXTENSIONS_H_
#define __SAISWITCHEXTENSIONS_H_

#include <saiswitch.h>
#include <saitypesextensions.h>

#define SAI_SWITCH_DEFAULT_ACL_USER_DEFINE_TRAP_ATTR_ID_RANGE 0x13

/**
 * @brief DASH capability HA scope level
 */
typedef enum _sai_dash_caps_ha_scope_level_t
{
    /** Card level HA scope */
    SAI_DASH_CAPS_HA_SCOPE_LEVEL_CARD,

    /** ENI level HA scope */
    SAI_DASH_CAPS_HA_SCOPE_LEVEL_ENI,
} sai_dash_caps_ha_scope_level_t;

/**
 * @brief HA set event type
 */
typedef enum _sai_ha_set_event_t
{
    /** Data plane channel goes up. */
    SAI_HA_SET_EVENT_DP_CHANNEL_UP,

    /** Data plane channel goes down. */
    SAI_HA_SET_EVENT_DP_CHANNEL_DOWN,

} sai_ha_set_event_t;

/**
 * @brief Notification data format received from SAI HA set callback
 */
typedef struct _sai_ha_set_event_data_t
{
    /** Event type */
    sai_ha_set_event_t event_type;

    /** HA set id */
    sai_object_id_t ha_set_id;

} sai_ha_set_event_data_t;

/**
 * @brief HA set event notification
 *
 * Passed as a parameter into sai_initialize_switch()
 *
 * @count data[count]
 *
 * @param[in] count Number of notifications
 * @param[in] data Array of HA set events
 */
typedef void (*sai_ha_set_event_notification_fn)(
        _In_ uint32_t count,
        _In_ const sai_ha_set_event_data_t *data);

/**
 * @brief HA scope event type
 */
typedef enum _sai_ha_scope_event_t
{
    /** HA scope state changed */
    SAI_HA_SCOPE_EVENT_STATE_CHANGED,

    /** Flow reconcile is needed */
    SAI_HA_SCOPE_EVENT_FLOW_RECONCILE_NEEDED,

    /** DPU driven HA split brain detected */
    SAI_HA_SCOPE_EVENT_SPLIT_BRAIN_DETECTED,
} sai_ha_scope_event_t;

/**
 * @brief Notification data format received from SAI HA scope callback
 */
typedef struct _sai_ha_scope_event_data_t
{
    /** Event type */
    sai_ha_scope_event_t event_type;

    /** HA scope id */
    sai_object_id_t ha_scope_id;

    /** HA role */
    sai_dash_ha_role_t ha_role;

    /** Flow version */
    sai_uint32_t flow_version;

    /** HA state */
    sai_dash_ha_state_t ha_state;

} sai_ha_scope_event_data_t;

/**
 * @brief HA scope event notification
 *
 * Passed as a parameter into sai_initialize_switch()
 *
 * @count data[count]
 *
 * @param[in] count Number of notifications
 * @param[in] data Array of HA scope events
 */
typedef void (*sai_ha_scope_event_notification_fn)(
        _In_ uint32_t count,
        _In_ const sai_ha_scope_event_data_t *data);

/**
 * @brief SAI switch attribute extensions.
 *
 * @flags free
 */
typedef enum _sai_switch_attr_extensions_t
{
    SAI_SWITCH_ATTR_EXTENSIONS_RANGE_START = SAI_SWITCH_ATTR_EXTENSIONS_RANGE_BASE,

    /**
     * @brief Maximum number of meter buckets per ENI.
     *
     * @type sai_uint32_t
     * @flags READ_ONLY
     */
    SAI_SWITCH_ATTR_DASH_CAPS_MAX_METER_BUCKET_COUNT_PER_ENI = SAI_SWITCH_ATTR_EXTENSIONS_RANGE_START,

    /**
     * @brief DASH capability HA scope level.
     *
     * It indicates on which level HA scope can be supported, such as ENI or Card.
     *
     * @type sai_dash_caps_ha_scope_level_t
     * @flags READ_ONLY
     */
    SAI_SWITCH_ATTR_DASH_CAPS_HA_SCOPE_LEVEL,

    /**
     * @brief DASH capability HA owner needed.
     *
     * If true, the DASH host need to own driving the HA state machine, otherwise the DASH
     * implementation can drive the HA state machine by itself.
     *
     * @type bool
     * @flags READ_ONLY
     */
    SAI_SWITCH_ATTR_DASH_CAPS_HA_OWNER_NEEDED,

    /**
     * @brief DASH HA set event notification
     *
     * Use sai_ha_set_event_notification_fn as notification function.
     *
     * @type sai_pointer_t sai_ha_set_event_notification_fn
     * @flags CREATE_AND_SET
     * @default NULL
     */
    SAI_SWITCH_ATTR_HA_SET_EVENT_NOTIFY,

    /**
     * @brief DASH HA set scope notification
     *
     * Use sai_ha_scope_event_notification_fn as notification function.
     *
     * @type sai_pointer_t sai_ha_scope_event_notification_fn
     * @flags CREATE_AND_SET
     * @default NULL
     */
    SAI_SWITCH_ATTR_HA_SCOPE_EVENT_NOTIFY,

    /**
     * @brief Set Switch Y1731 session event notification callback function passed to the adapter.
     *
     * Use sai_y1731_session_state_change_notification_fn as notification function.
     *
     * @type sai_pointer_t sai_y1731_session_state_change_notification_fn
     * @flags CREATE_AND_SET
     * @default NULL
     */
    SAI_SWITCH_ATTR_Y1731_SESSION_STATE_CHANGE_NOTIFY,

    /**
     * @brief Number of Y1731 session in the NPU
     *
     * @type sai_uint32_t
     * @flags READ_ONLY
     */
    SAI_SWITCH_ATTR_NUMBER_OF_Y1731_SESSION,

    /**
     * @brief Max number of Y1731 session NPU supports
     *
     * @type sai_uint32_t
     * @flags READ_ONLY
     */
    SAI_SWITCH_ATTR_MAX_Y1731_SESSION,

    /**
     * @brief List of Y1731 session performance monitor offloads supported in the ASIC
     *
     * @type sai_s32_list_t sai_y1731_session_perf_monitor_offload_type_t
     * @flags READ_ONLY
     */
    SAI_SWITCH_ATTR_SUPPORTED_Y1731_SESSION_PERF_MONITOR_OFFLOAD_TYPE,

    /**
     * @brief Apply ECN action for ECT traffic.
     * Attribute controls whether do ECN modification when traffic beyond
     * the ECN threshold.
     *
     * @type bool
     * @flags CREATE_AND_SET
     * @default false
     */
    SAI_SWITCH_ATTR_ECN_ACTION_ENABLE,

    /**
     * @brief Buffer monitor notification callback function passed to the adapter.
     *
     * Use sai_monitor_buffer_notification_fn as notification function.
     *
     * @type sai_pointer_t sai_monitor_buffer_notification_fn
     * @flags CREATE_AND_SET
     * @default NULL
     */
    SAI_SWITCH_ATTR_MONITOR_BUFFER_NOTIFY,

    /**
     * @brief Latency monitor notification callback function passed to the adapter.
     *
     * Use sai_monitor_latency_notification_fn as notification function.
     *
     * @type sai_pointer_t sai_monitor_latency_notification_fn
     * @flags CREATE_AND_SET
     * @default NULL
     */
    SAI_SWITCH_ATTR_MONITOR_LATENCY_NOTIFY,

    /**
     * @brief Buffer monitor microburst enable
     *
     * @type bool
     * @flags CREATE_AND_SET
     * @default false
     */
    SAI_SWITCH_ATTR_MONITOR_BUFFER_MONITOR_MB_ENABLE,

    /**
     * @brief Define the min threshold of microburst, global control(unit is byte)
     *
     * @type sai_uint32_t
     * @flags CREATE_AND_SET
     * @default 0
     */
    SAI_SWITCH_ATTR_MONITOR_BUFFER_MONITOR_MB_TOTAL_MIN_THRD,

    /**
     * @brief Define the max threshold of microburst, global control(unit is byte)
     *
     * @type sai_uint32_t
     * @flags CREATE_AND_SET
     * @default 0
     */
    SAI_SWITCH_ATTR_MONITOR_BUFFER_MONITOR_MB_TOTAL_MAX_THRD,

    /**
     * @brief Send the packet to CPU when the usage of buffer over the threshold
     *
     * @type bool
     * @flags CREATE_AND_SET
     * @default false
     */
    SAI_SWITCH_ATTR_MONITOR_BUFFER_MONITOR_MB_OVERTHRD_EVENT,

    /**
     * @brief Set 8 level threshold(unit is Nanosecond) for the duration of microburst
     *
     * @type sai_u32_list_t
     * @flags CREATE_AND_SET
     * @default empty
     */
    SAI_SWITCH_ATTR_MONITOR_BUFFER_MONITOR_MB_LEVEL_THRESHOLD,

    /**
     * @brief Enable the ingress monitor, global control
     *
     * @type bool
     * @flags CREATE_AND_SET
     * @default false
     */
    SAI_SWITCH_ATTR_MONITOR_BUFFER_MONITOR_INGRESS_PERIODIC_MONITOR_ENABLE,

    /**
     * @brief Enable the egress monitor, global control
     *
     * @type bool
     * @flags CREATE_AND_SET
     * @default false
     */
    SAI_SWITCH_ATTR_MONITOR_BUFFER_MONITOR_EGRESS_PERIODIC_MONITOR_ENABLE,

    /**
     * @brief Enable the egress monitor based on queue, global control
     *
     * @type bool
     * @flags CREATE_AND_SET
     * @default false
     */
    SAI_SWITCH_ATTR_MONITOR_BUFFER_MONITOR_EGRESS_QUEUE_PERIODIC_MONITOR_ENABLE,

    /**
     * @brief The buffer monitor time interval(ms)
     *
     * @type sai_uint32_t
     * @flags CREATE_AND_SET
     * @default 0
     */
    SAI_SWITCH_ATTR_MONITOR_BUFFER_MONITOR_TIME_INTERVAL,

    /**
     * @brief Record max total buffer count(unit is byte), and when set the attr,the value can only be 0, indicate clearing watermark
     *
     * @type sai_uint32_t
     * @flags CREATE_AND_SET
     * @default 0
     */
    SAI_SWITCH_ATTR_MONITOR_BUFFER_MONITOR_INGRESS_WATERMARK,

    /**
     * @brief Record max total buffer count(unit is byte), and when set the attr,the value can only be 0, indicate clearing watermark
     *
     * @type sai_uint32_t
     * @flags CREATE_AND_SET
     * @default 0
     */
    SAI_SWITCH_ATTR_MONITOR_BUFFER_MONITOR_EGRESS_WATERMARK,

    /**
     * @brief Define the min latency threshold(unit is Nanosecond)
     *
     * @type sai_uint32_t
     * @flags CREATE_AND_SET
     * @default 0
     */
    SAI_SWITCH_ATTR_MONITOR_LATENCY_MONITOR_MIN_THRESHOLD,

    /**
     * @brief Define the max latency threshold (unit is Nanosecond)
     *
     * @type sai_uint32_t
     * @flags CREATE_AND_SET
     * @default 0
     */
    SAI_SWITCH_ATTR_MONITOR_LATENCY_MONITOR_MAX_THRESHOLD,

    /**
     * @brief Set 8 level threshold(unit is Nanosecond)
     *
     * @type sai_u32_list_t
     * @flags CREATE_AND_SET
     * @default empty
     */
    SAI_SWITCH_ATTR_MONITOR_LATENCY_MONITOR_LEVEL_THRESHOLD,

    /**
     * @brief Set the latency monitor scan time interval(ms)
     *
     * @type sai_uint32_t
     * @flags CREATE_AND_SET
     * @default 0
     */
    SAI_SWITCH_ATTR_MONITOR_LATENCY_MONITOR_INTERVAL,

    /**
     * @brief Set signal degrade event notification callback function passed to the adapter.
     *
     * Use sai_signal_degrade_event_notification_fn as notification function.
     *
     * @type sai_pointer_t sai_signal_degrade_event_notification_fn
     * @flags CREATE_AND_SET
     * @default NULL
     */
    SAI_SWITCH_ATTR_SIGNAL_DEGRADE_EVENT_NOTIFY,

    /**
     * @brief Set PTP packet tx event notification callback function passed to the adapter.
     *
     * Use sai_packet_event_ptp_tx_notification_fn as notification function.
     *
     * @type sai_pointer_t sai_packet_event_ptp_tx_notification_fn
     * @flags CREATE_AND_SET
     * @default NULL
     */
    SAI_SWITCH_ATTR_PACKET_EVENT_PTP_TX_NOTIFY,

    /**
     * @brief Flex Ethernet Group Event notification callback function passed to the adapter.
     *
     * Use sai_flexe_group_event_notification_fn as notification function.
     *
     * @type sai_pointer_t sai_flexe_group_event_notification_fn
     * @flags CREATE_AND_SET
     * @default NULL
     */
    SAI_SWITCH_ATTR_FLEXE_GROUP_EVENT_NOTIFY,

    /**
     * @brief Flex Ethernet Group Event State change notification callback function passed to the adapter.
     *
     * Use sai_flexe_event_state_change_notification_fn as notification function.
     *
     * @type sai_pointer_t sai_flexe_group_event_state_change_notification_fn
     * @flags CREATE_AND_SET
     * @default NULL
     */
    SAI_SWITCH_ATTR_FLEXE_GROUP_EVENT_STATE_CHANGE_NOTIFY,

    /**
     * @brief FDB SRC user-based meta data range
     *
     * @type sai_u32_range_t
     * @flags READ_ONLY
     */
    SAI_SWITCH_ATTR_FDB_SRC_USER_META_DATA_RANGE,

    /**
     * @brief MOX session notification callback function passed to the adapter.
     *
     * Use sai_monitor_mox_session_notification_fn as notification function.
     *
     * @type sai_pointer_t sai_monitor_mox_session_notification_fn
     * @flags CREATE_AND_SET
     * @default NULL
     */
    SAI_SWITCH_ATTR_MONITOR_MOX_SESSION_NOTIFY,

    /**
     * @brief MOX session flow aging time(s).
     *
     * @type sai_uint32_t
     * @flags CREATE_AND_SET
     * @default 0
     */
    SAI_SWITCH_ATTR_MONITOR_MOX_SESSION_FLOW_AGING_TIME,

    /**
     * @brief MOX session new flow first packet export enable.
     *
     * @type bool
     * @flags CREATE_AND_SET
     * @default false
     */
    SAI_SWITCH_ATTR_MONITOR_MOX_SESSION_FIRST_PACKET_EXPORT_ENABLE,

    /**
     * @brief MOX session export interval(ms).
     *
     * @type sai_uint32_t
     * @flags CREATE_AND_SET
     * @default 100
     */
    SAI_SWITCH_ATTR_MONITOR_MOX_SESSION_EXPORT_INTERVAL,

    /**
     * @brief MOX session drop packet number threshold
     *
     * @type sai_uint32_t
     * @flags CREATE_AND_SET
     * @default 512
     */
    SAI_SWITCH_ATTR_MONITOR_MOX_SESSION_DROP_PACKET_NUM_THRESHOLD,

    /**
     * @brief Default SAI ACL type user define trap
     *
     * @type sai_object_id_t
     * @flags READ_ONLY
     * @objects SAI_OBJECT_TYPE_HOSTIF_USER_DEFINED_TRAP
     * @default internal
     * @range SAI_SWITCH_DEFAULT_ACL_USER_DEFINE_TRAP_ATTR_ID_RANGE
     */
    SAI_SWITCH_ATTR_DEFAULT_ACL_USER_DEFINE_TRAP_MIN,

    /**
     * @brief Default SAI ACL type user define trap
     *
     * @type sai_object_id_t
     * @flags READ_ONLY
     * @objects SAI_OBJECT_TYPE_HOSTIF_USER_DEFINED_TRAP
     * @default internal
     */
    SAI_SWITCH_ATTR_DEFAULT_ACL_USER_DEFINE_TRAP_MAX = SAI_SWITCH_ATTR_DEFAULT_ACL_USER_DEFINE_TRAP_MIN + SAI_SWITCH_DEFAULT_ACL_USER_DEFINE_TRAP_ATTR_ID_RANGE,

    /**
     * @brief ECMP resilient hash enable.
     *
     * @type bool
     * @flags CREATE_AND_SET
     * @default false
     */
    SAI_SWITCH_ATTR_ECMP_RESILIENT_HASH,

    SAI_SWITCH_ATTR_EXTENSIONS_RANGE_END

} sai_switch_attr_extensions_t;

#endif /* __SAISWITCHEXTENSIONS_H_ */
