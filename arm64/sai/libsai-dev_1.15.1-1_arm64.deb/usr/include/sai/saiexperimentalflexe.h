/**
 * Copyright (c) 2014 Microsoft Open Technologies, Inc.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABILITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 *    Microsoft would like to thank the following companies for their review and
 *    assistance with these files: Intel Corporation, Mellanox Technologies Ltd,
 *    Dell Products, L.P., Facebook, Inc., Marvell International Ltd.
 *
 * @file    saiexperimentalflexe.h
 *
 * @brief   This module defines SAI Flexible Ethernet
 */

#if !defined (__SAIEXPERIMENTALFLEXE_H_)
#define __SAIEXPERIMENTALFLEXE_H_

#include <saitypes.h>

/**
 * @defgroup SAIEXPERIMENTALFLEXE SAI - Flexible Ethernet specific API definitions
 *
 * @{
 */

/**
 * @brief Attribute data for #SAI_FLEXE_GROUP_ATTR_SLOT_GRANULA
 */
typedef enum _sai_flexe_group_slot_granula_t
{
    /** 5G Slot */
    SAI_FLEXE_GROUP_SLOT_GRANULA_5G,

    /** 25G Slot */
    SAI_FLEXE_GROUP_SLOT_GRANULA_25G,

    /** 1G Slot */
    SAI_FLEXE_GROUP_SLOT_GRANULA_1G,

    /** 2.5G Slot */
    SAI_FLEXE_GROUP_SLOT_GRANULA_HALF_5G,

    /** 1.25G Slot */
    SAI_FLEXE_GROUP_SLOT_GRANULA_QUARTER_5G

} sai_flexe_group_slot_granula_t;

/**
 * @brief Attribute data for #SAI_FLEXE_GROUP_ATTR_CALENDAR_SWITCH_MODE
 */
typedef enum _sai_flexe_group_calendar_switch_mode_t
{
    /** Full protocol dynamic Mode with CR CA C process in ASIC */
    SAI_FLEXE_GROUP_CALENDAR_SWITCH_MODE_DYNAMIC,

    /** Static Mode */
    SAI_FLEXE_GROUP_CALENDAR_SWITCH_MODE_STATIC,

} sai_flexe_group_calendar_switch_mode_t;

/**
 * @brief Attribute data for #SAI_FLEXE_GROUP_ATTR_TX_CURRENT_CALENDAR
 */
typedef enum _sai_flexe_group_tx_current_calendar_t
{
    /** Calendar A */
    SAI_FLEXE_GROUP_TX_CURRENT_CALENDAR_A,

    /** Calendar B */
    SAI_FLEXE_GROUP_TX_CURRENT_CALENDAR_B,

} sai_flexe_group_tx_current_calendar_t;

/**
 * @brief Attribute data for #SAI_FLEXE_GROUP_ATTR_RX_CURRENT_CALENDAR
 */
typedef enum _sai_flexe_group_rx_current_calendar_t
{
    /** Calendar A */
    SAI_FLEXE_GROUP_RX_CURRENT_CALENDAR_A,

    /** Calendar B */
    SAI_FLEXE_GROUP_RX_CURRENT_CALENDAR_B,

} sai_flexe_group_rx_current_calendar_t;

/**
 * @brief Attribute data for #SAI_FLEXE_GROUP_ATTR_TX_ASSIGNED_CALENDAR
 */
typedef enum _sai_flexe_group_tx_assigned_calendar_t
{
    /** Calendar None for Flex Ethernet Group Full Protocol Dynamic Switch Mode */
    SAI_FLEXE_GROUP_TX_ASSIGNED_CALENDAR_NOT_IN_USE,

    /** Calendar A */
    SAI_FLEXE_GROUP_TX_ASSIGNED_CALENDAR_A,

    /** Calendar B */
    SAI_FLEXE_GROUP_TX_ASSIGNED_CALENDAR_B,

} sai_flexe_group_tx_assigned_calendar_t;

/**
 * @brief Attribute data for #SAI_FLEXE_GROUP_ATTR_RX_ASSIGNED_CALENDAR
 */
typedef enum _sai_flexe_group_rx_assigned_calendar_t
{
    /** Calendar None for Flex Ethernet Group Full Protocol Dynamic Switch Mode */
    SAI_FLEXE_GROUP_RX_ASSIGNED_CALENDAR_NOT_IN_USE,

    /** Calendar A */
    SAI_FLEXE_GROUP_RX_ASSIGNED_CALENDAR_A,

    /** Calendar B */
    SAI_FLEXE_GROUP_RX_ASSIGNED_CALENDAR_B,

} sai_flexe_group_rx_assigned_calendar_t;

/**
 * @brief Flexible Ethernet group attributes
 */
typedef enum _sai_flexe_group_attr_t
{
    /**
     * @brief Start of attributes
     */
    SAI_FLEXE_GROUP_ATTR_START,

    /**
     * @brief Flexible Ethernet Physical Port ID
     *
     * @type sai_object_list_t
     * @flags MANDATORY_ON_CREATE | CREATE_ONLY
     * @objects SAI_OBJECT_TYPE_PORT
     */
    SAI_FLEXE_GROUP_ATTR_PHY_PORT_LIST = SAI_FLEXE_GROUP_ATTR_START,

    /**
     * @brief Flexible Ethernet Group Number from 1 to 1048574
     *
     * @type sai_uint32_t
     * @flags MANDATORY_ON_CREATE | CREATE_AND_SET
     * @isvlan false
     */
    SAI_FLEXE_GROUP_ATTR_GROUP_NUM,

    /**
     * @brief Flexible Ethernet Group Slot granular
     *
     * @type sai_flexe_group_slot_granula_t
     * @flags MANDATORY_ON_CREATE | CREATE_ONLY
     */
    SAI_FLEXE_GROUP_ATTR_SLOT_GRANULA,

    /**
     * @brief Flexible Ethernet Group Calendar A/B switch mode
     *
     * @type sai_flexe_group_calendar_switch_mode_t
     * @flags CREATE_AND_SET
     * @default SAI_FLEXE_GROUP_CALENDAR_SWITCH_MODE_DYNAMIC
     */
    SAI_FLEXE_GROUP_ATTR_CALENDAR_SWITCH_MODE,

    /**
     * @brief Flexible Ethernet Group Assigned Calendar
     *
     * @type sai_flexe_group_tx_assigned_calendar_t
     * @flags CREATE_AND_SET
     * @default SAI_FLEXE_GROUP_TX_ASSIGNED_CALENDAR_NOT_IN_USE
     * @validonly SAI_FLEXE_GROUP_ATTR_CALENDAR_SWITCH_MODE == SAI_FLEXE_GROUP_CALENDAR_SWITCH_MODE_STATIC
     */
    SAI_FLEXE_GROUP_ATTR_TX_ASSIGNED_CALENDAR,

    /**
     * @brief Flexible Ethernet Group Assigned Calendar
     *
     * @type sai_flexe_group_rx_assigned_calendar_t
     * @flags CREATE_AND_SET
     * @default SAI_FLEXE_GROUP_RX_ASSIGNED_CALENDAR_NOT_IN_USE
     * @validonly SAI_FLEXE_GROUP_ATTR_CALENDAR_SWITCH_MODE == SAI_FLEXE_GROUP_CALENDAR_SWITCH_MODE_STATIC
     */
    SAI_FLEXE_GROUP_ATTR_RX_ASSIGNED_CALENDAR,

    /**
     * @brief Flexible Ethernet Group Current Calendar A/B for TX
     *
     * @type sai_flexe_group_tx_current_calendar_t
     * @flags READ_ONLY
     */
    SAI_FLEXE_GROUP_ATTR_TX_CURRENT_CALENDAR,

    /**
     * @brief Flexible Ethernet Group Current Calendar A/B for RX
     *
     * @type sai_flexe_group_rx_current_calendar_t
     * @flags READ_ONLY
     */
    SAI_FLEXE_GROUP_ATTR_RX_CURRENT_CALENDAR,

    /**
     * @brief Trigger Flexible Ethernet Group auto mode Calendar A/B tx switch, rx act as slave
     *
     * @type sai_uint16_t
     * @flags CREATE_AND_SET
     * @isvlan false
     * @default 0
     */
    SAI_FLEXE_GROUP_ATTR_TX_CALENDAR_DYNAMIC_SWITCH,

    /**
     * @brief Trigger Flexible Ethernet Group CR bit for Calendar A/B
     *
     * @type sai_uint16_t
     * @flags CREATE_AND_SET
     * @isvlan false
     * @default 0
     */
    SAI_FLEXE_GROUP_ATTR_TX_CR_BIT,

    /**
     * @brief Trigger Flexible Ethernet Group CA bit for Calendar A/B
     *
     * @type sai_uint16_t
     * @flags CREATE_AND_SET
     * @isvlan false
     * @default 0
     */
    SAI_FLEXE_GROUP_ATTR_TX_CA_BIT,

    /**
     * @brief Trigger Flexible Ethernet Group Calendar A force switch
     *
     * @type sai_uint16_t
     * @flags CREATE_AND_SET
     * @isvlan false
     * @default 0
     */
    SAI_FLEXE_GROUP_ATTR_TX_FORCE_SWITCH_CALENDAR_A,

    /**
     * @brief Trigger Flexible Ethernet Group Calendar B force switch
     *
     * @type sai_uint16_t
     * @flags CREATE_AND_SET
     * @isvlan false
     * @default 0
     */
    SAI_FLEXE_GROUP_ATTR_TX_FORCE_SWITCH_CALENDAR_B,

    /**
     * @brief Trigger Flexible Ethernet Group Calendar A force switch
     *
     * @type sai_uint16_t
     * @flags CREATE_AND_SET
     * @isvlan false
     * @default 0
     */
    SAI_FLEXE_GROUP_ATTR_RX_FORCE_SWITCH_CALENDAR_A,

    /**
     * @brief Trigger Flexible Ethernet Group Calendar B force switch
     *
     * @type sai_uint16_t
     * @flags CREATE_AND_SET
     * @isvlan false
     * @default 0
     */
    SAI_FLEXE_GROUP_ATTR_RX_FORCE_SWITCH_CALENDAR_B,

    /**
     * @brief Flexible Ethernet Client List in Calendar A of Flexible Ethernet Group
     *
     * @type sai_object_list_t
     * @flags READ_ONLY
     * @objects SAI_OBJECT_TYPE_PORT
     */
    SAI_FLEXE_GROUP_ATTR_CALENDAR_A_CLIENT_LIST_TX,

    /**
     * @brief Flexible Ethernet Client List in Calendar A of Flexible Ethernet Group
     *
     * @type sai_object_list_t
     * @flags READ_ONLY
     * @objects SAI_OBJECT_TYPE_PORT
     */
    SAI_FLEXE_GROUP_ATTR_CALENDAR_A_CLIENT_LIST_RX,

    /**
     * @brief Flexible Ethernet Client List in Calendar B of Flexible Ethernet Group
     *
     * @type sai_object_list_t
     * @flags READ_ONLY
     * @objects SAI_OBJECT_TYPE_PORT
     */
    SAI_FLEXE_GROUP_ATTR_CALENDAR_B_CLIENT_LIST_TX,

    /**
     * @brief Flexible Ethernet Client List in Calendar B of Flexible Ethernet Group
     *
     * @type sai_object_list_t
     * @flags READ_ONLY
     * @objects SAI_OBJECT_TYPE_PORT
     */
    SAI_FLEXE_GROUP_ATTR_CALENDAR_B_CLIENT_LIST_RX,

    /**
     * @brief End of attributes
     */
    SAI_FLEXE_GROUP_ATTR_END,

    /** Custom range base value */
    SAI_FLEXE_GROUP_ATTR_CUSTOM_RANGE_START = 0x10000000,

    /** End of custom range base */
    SAI_FLEXE_GROUP_ATTR_CUSTOM_RANGE_END

} sai_flexe_group_attr_t;

/**
 * @brief Create Flex Ethernet group
 *
 * @param[out] flexe_group_id Flex Ethernet group id
 * @param[in] switch_id Switch object id
 * @param[in] attr_count Number of attributes
 * @param[in] attr_list Array of attributes
 *
 * @return #SAI_STATUS_SUCCESS on success, failure status code on error
 */
typedef sai_status_t (*sai_create_flexe_group_fn)(
        _Out_ sai_object_id_t *flexe_group_id,
        _In_ sai_object_id_t switch_id,
        _In_ uint32_t attr_count,
        _In_ const sai_attribute_t *attr_list);

/**
 * @brief Remove Flex Ethernet group
 *
 * @param[in] flexe_group_id Flex Ethernet group id
 *
 * @return #SAI_STATUS_SUCCESS on success, failure status code on error
 */
typedef sai_status_t (*sai_remove_flexe_group_fn)(
        _In_ sai_object_id_t flexe_group_id);

/**
 * @brief Set Flex Ethernet group attribute value
 *
 * @param[in] flexe_group_id Flex Ethernet group id
 * @param[in] attr Attribute
 *
 * @return #SAI_STATUS_SUCCESS on success, failure status code on error
 */
typedef sai_status_t (*sai_set_flexe_group_attribute_fn)(
        _In_ sai_object_id_t flexe_group_id,
        _In_ const sai_attribute_t *attr);

/**
 * @brief Get Flex Ethernet group attribute value
 *
 * @param[in] flexe_group_id Flex Ethernet group id
 * @param[in] attr_count Number of attributes
 * @param[inout] attr_list Array of attributes
 *
 * @return #SAI_STATUS_SUCCESS on success, failure status code on error
 */
typedef sai_status_t (*sai_get_flexe_group_attribute_fn)(
        _In_ sai_object_id_t flexe_group_id,
        _In_ uint32_t attr_count,
        _Inout_ sai_attribute_t *attr_list);

/**
 * @brief Flexible Ethernet slot attributes
 */
typedef enum _sai_flexe_slot_attr_t
{
    /**
     * @brief Start of attributes
     */
    SAI_FLEXE_SLOT_ATTR_START,

    /**
     * @brief Flexible Ethernet PHY Port for the slot
     *
     * @type sai_object_id_t
     * @flags MANDATORY_ON_CREATE | CREATE_ONLY
     * @objects SAI_OBJECT_TYPE_PORT
     */
    SAI_FLEXE_SLOT_ATTR_PHY_PORT = SAI_FLEXE_SLOT_ATTR_START,

    /**
     * @brief Flexible Ethernet Instance Number for the slot
     *
     * @type sai_uint8_t
     * @flags READ_ONLY
     */
    SAI_FLEXE_SLOT_ATTR_INSTANCE_NUM,

    /**
     * @brief Flexible Ethernet Slot Offset for the slot from 0-79
     *
     * @type sai_uint16_t
     * @flags MANDATORY_ON_CREATE | CREATE_ONLY
     * @isvlan false
     */
    SAI_FLEXE_SLOT_ATTR_SLOT_OFFSET,

    /**
     * @brief Flexible Ethernet Client for the slot in Calendar A
     *
     * @type sai_object_id_t
     * @flags READ_ONLY
     * @objects SAI_OBJECT_TYPE_FLEXE_CLIENT
     */
    SAI_FLEXE_SLOT_ATTR_TX_FLEXE_CLIENT_CALENDAR_A,

    /**
     * @brief Flexible Ethernet Client for the slot in Calendar B
     *
     * @type sai_object_id_t
     * @flags READ_ONLY
     * @objects SAI_OBJECT_TYPE_FLEXE_CLIENT
     */
    SAI_FLEXE_SLOT_ATTR_TX_FLEXE_CLIENT_CALENDAR_B,

    /**
     * @brief Flexible Ethernet Client for the slot in Calendar A
     *
     * @type sai_object_id_t
     * @flags READ_ONLY
     * @objects SAI_OBJECT_TYPE_FLEXE_CLIENT
     */
    SAI_FLEXE_SLOT_ATTR_RX_FLEXE_CLIENT_CALENDAR_A,

    /**
     * @brief Flexible Ethernet Client for the slot in Calendar B
     *
     * @type sai_object_id_t
     * @flags READ_ONLY
     * @objects SAI_OBJECT_TYPE_FLEXE_CLIENT
     */
    SAI_FLEXE_SLOT_ATTR_RX_FLEXE_CLIENT_CALENDAR_B,

    /**
     * @brief End of attributes
     */
    SAI_FLEXE_SLOT_ATTR_END,

    /** Custom range base value */
    SAI_FLEXE_SLOT_ATTR_CUSTOM_RANGE_START = 0x10000000,

    /** End of custom range base */
    SAI_FLEXE_SLOT_ATTR_CUSTOM_RANGE_END

} sai_flexe_slot_attr_t;

/**
 * @brief Create Flex Ethernet slot
 *
 * @param[out] flexe_slot_id Flex Ethernet slot id
 * @param[in] switch_id Switch object Id
 * @param[in] attr_count Number of attributes
 * @param[in] attr_list Array of attributes
 *
 * @return #SAI_STATUS_SUCCESS on success, failure status code on error
 */
typedef sai_status_t (*sai_create_flexe_slot_fn)(
        _Out_ sai_object_id_t *flexe_slot_id,
        _In_ sai_object_id_t switch_id,
        _In_ uint32_t attr_count,
        _In_ const sai_attribute_t *attr_list);

/**
 * @brief Remove Flex Ethernet slot
 *
 * @param[in] flexe_slot_id Flex Ethernet slot id
 *
 * @return #SAI_STATUS_SUCCESS on success, failure status code on error
 */
typedef sai_status_t (*sai_remove_flexe_slot_fn)(
        _In_ sai_object_id_t flexe_slot_id);

/**
 * @brief Set Flex Ethernet slot attribute value
 *
 * @param[in] flexe_slot_id Flex Ethernet slot id
 * @param[in] attr Attribute
 *
 * @return #SAI_STATUS_SUCCESS on success, failure status code on error
 */
typedef sai_status_t (*sai_set_flexe_slot_attribute_fn)(
        _In_ sai_object_id_t flexe_slot_id,
        _In_ const sai_attribute_t *attr);

/**
 * @brief Get Flex Ethernet slot attribute value
 *
 * @param[in] flexe_slot_id Flex Ethernet slot id
 * @param[in] attr_count Number of attributes
 * @param[inout] attr_list Array of attributes
 *
 * @return #SAI_STATUS_SUCCESS on success, failure status code on error
 */
typedef sai_status_t (*sai_get_flexe_slot_attribute_fn)(
        _In_ sai_object_id_t flexe_slot_id,
        _In_ uint32_t attr_count,
        _Inout_ sai_attribute_t *attr_list);

/**
 * @brief Attribute data for #SAI_FLEXE_CLIENT_ATTR_OBSERVED_ROLE_RX
 */
typedef enum _sai_flexe_client_observed_role_rx_t
{
    /** Active */
    SAI_FLEXE_CLIENT_OBSERVED_ROLE_RX_ACTIVE,

    /** Inactive */
    SAI_FLEXE_CLIENT_OBSERVED_ROLE_RX_INACTIVE,

} sai_flexe_client_observed_role_rx_t;

/**
 * @brief Attribute data for #SAI_FLEXE_CLIENT_ATTR_OBSERVED_ROLE_TX
 */
typedef enum _sai_flexe_client_observed_role_tx_t
{
    /** Active */
    SAI_FLEXE_CLIENT_OBSERVED_ROLE_TX_ACTIVE,

    /** Inactive */
    SAI_FLEXE_CLIENT_OBSERVED_ROLE_TX_INACTIVE,

} sai_flexe_client_observed_role_tx_t;

/**
 * @brief Flexible Ethernet client attributes
 */
typedef enum _sai_flexe_client_attr_t
{
    /**
     * @brief Start of attributes
     */
    SAI_FLEXE_CLIENT_ATTR_START,

    /**
     * @brief Flexible Ethernet Client Number
     *
     * @type sai_object_id_t
     * @flags MANDATORY_ON_CREATE | CREATE_ONLY
     * @objects SAI_OBJECT_TYPE_FLEXE_GROUP
     */
    SAI_FLEXE_CLIENT_ATTR_FLEXE_GROUP = SAI_FLEXE_CLIENT_ATTR_START,

    /**
     * @brief Flexible Ethernet Client Number from 1 to 65535
     *
     * @type sai_uint16_t
     * @flags MANDATORY_ON_CREATE | CREATE_AND_SET
     * @isvlan false
     */
    SAI_FLEXE_CLIENT_ATTR_CLIENT_NUM,

    /**
     * @brief Flexible Ethernet Client slot list, calendar A/B switching is needed when this attribute updated
     *
     * @type sai_object_list_t
     * @flags CREATE_AND_SET
     * @objects SAI_OBJECT_TYPE_FLEXE_SLOT
     * @default empty
     */
    SAI_FLEXE_CLIENT_ATTR_FLEXE_SLOT_LIST,

    /**
     * @brief Flexible Ethernet Client Observed Role RX
     *
     * @type sai_flexe_client_observed_role_rx_t
     * @flags READ_ONLY
     */
    SAI_FLEXE_CLIENT_ATTR_OBSERVED_ROLE_RX,

    /**
     * @brief Flexible Ethernet Client Observed Role TX
     *
     * @type sai_flexe_client_observed_role_tx_t
     * @flags READ_ONLY
     */
    SAI_FLEXE_CLIENT_ATTR_OBSERVED_ROLE_TX,

    /**
     * @brief Flexible Ethernet Client L1 cross connect
     *
     * @type sai_object_id_t
     * @flags READ_ONLY
     * @objects SAI_OBJECT_TYPE_FLEXE_CLIENT
     */
    SAI_FLEXE_CLIENT_ATTR_CROSS_CONNECT_FLEXE_CLIENT,

    /**
     * @brief End of attributes
     */
    SAI_FLEXE_CLIENT_ATTR_END,

    /** Custom range base value */
    SAI_FLEXE_CLIENT_ATTR_CUSTOM_RANGE_START = 0x10000000,

    /** End of custom range base */
    SAI_FLEXE_CLIENT_ATTR_CUSTOM_RANGE_END

} sai_flexe_client_attr_t;

/**
 * @brief Create Flex Ethernet client
 *
 * @param[out] flexe_client_id Flex Ethernet client id
 * @param[in] switch_id Switch object id
 * @param[in] attr_count Number of attributes
 * @param[in] attr_list Array of attributes
 *
 * @return #SAI_STATUS_SUCCESS on success, failure status code on error
 */
typedef sai_status_t (*sai_create_flexe_client_fn)(
        _Out_ sai_object_id_t *flexe_client_id,
        _In_ sai_object_id_t switch_id,
        _In_ uint32_t attr_count,
        _In_ const sai_attribute_t *attr_list);

/**
 * @brief Remove Flex Ethernet client
 *
 * @param[in] flexe_client_id Flex Ethernet client id
 *
 * @return #SAI_STATUS_SUCCESS on success, failure status code on error
 */
typedef sai_status_t (*sai_remove_flexe_client_fn)(
        _In_ sai_object_id_t flexe_client_id);

/**
 * @brief Set Flex Ethernet client attribute value
 *
 * @param[in] flexe_client_id Flex Ethernet client id
 * @param[in] attr Attribute
 *
 * @return #SAI_STATUS_SUCCESS on success, failure status code on error
 */
typedef sai_status_t (*sai_set_flexe_client_attribute_fn)(
        _In_ sai_object_id_t flexe_client_id,
        _In_ const sai_attribute_t *attr);

/**
 * @brief Get Flex Ethernet client attributes
 *
 * @param[in] flexe_client_id Flex Ethernet client id
 * @param[in] attr_count Number of attributes
 * @param[inout] attr_list Array of attributes
 *
 * @return #SAI_STATUS_SUCCESS on success, failure status code on error
 */
typedef sai_status_t (*sai_get_flexe_client_attribute_fn)(
        _In_ sai_object_id_t flexe_client_id,
        _In_ uint32_t attr_count,
        _Inout_ sai_attribute_t *attr_list);

/**
 * @brief Flexible Ethernet client cross connect attributes
 */
typedef enum _sai_flexe_client_cross_connect_attr_t
{
    /**
     * @brief Start of attributes
     */
    SAI_FLEXE_CLIENT_CROSS_CONNECT_ATTR_START,

    /**
     * @brief Flexible Ethernet Client List for cross connect
     *
     * @type sai_object_list_t
     * @flags MANDATORY_ON_CREATE | CREATE_ONLY
     * @objects SAI_OBJECT_TYPE_FLEXE_CLIENT
     */
    SAI_FLEXE_CLIENT_CROSS_CONNECT_ATTR_CLIENT_LIST = SAI_FLEXE_CLIENT_CROSS_CONNECT_ATTR_START,

    /**
     * @brief End of attributes
     */
    SAI_FLEXE_CLIENT_CROSS_CONNECT_ATTR_END,

    /** Custom range base value */
    SAI_FLEXE_CLIENT_CROSS_CONNECT_ATTR_CUSTOM_RANGE_START = 0x10000000,

    /** End of custom range base */
    SAI_FLEXE_CLIENT_CROSS_CONNECT_ATTR_CUSTOM_RANGE_END

} sai_flexe_client_cross_connect_attr_t;

/**
 * @brief Create Flex Ethernet client cross connect
 *
 * @param[out] flexe_client_cross_connect_id Flex Ethernet client cross connect id
 * @param[in] switch_id Switch object id
 * @param[in] attr_count Number of attributes
 * @param[in] attr_list Array of attributes
 *
 * @return #SAI_STATUS_SUCCESS on success, failure status code on error
 */
typedef sai_status_t (*sai_create_flexe_client_cross_connect_fn)(
        _Out_ sai_object_id_t *flexe_client_cross_connect_id,
        _In_ sai_object_id_t switch_id,
        _In_ uint32_t attr_count,
        _In_ const sai_attribute_t *attr_list);

/**
 * @brief Remove Flex Ethernet client cross connect
 *
 * @param[in] flexe_client_cross_connect_id Flex Ethernet client cross connect id
 *
 * @return #SAI_STATUS_SUCCESS on success, failure status code on error
 */
typedef sai_status_t (*sai_remove_flexe_client_cross_connect_fn)(
        _In_ sai_object_id_t flexe_client_cross_connect_id);

/**
 * @brief Set Flex Ethernet client cross connect attribute value
 *
 * @param[in] flexe_client_cross_connect_id Flex Ethernet client cross connect id
 * @param[in] attr Attribute
 *
 * @return #SAI_STATUS_SUCCESS on success, failure status code on error
 */
typedef sai_status_t (*sai_set_flexe_client_cross_connect_attribute_fn)(
        _In_ sai_object_id_t flexe_client_cross_connect_id,
        _In_ const sai_attribute_t *attr);

/**
 * @brief Get Flex Ethernet client cross connect attribute value
 *
 * @param[in] flexe_client_cross_connect_id Flex Ethernet client cross connect id
 * @param[in] attr_count Number of attributes
 * @param[inout] attr_list Array of attributes
 *
 * @return #SAI_STATUS_SUCCESS on success, failure status code on error
 */
typedef sai_status_t (*sai_get_flexe_client_cross_connect_attribute_fn)(
        _In_ sai_object_id_t flexe_client_cross_connect_id,
        _In_ uint32_t attr_count,
        _Inout_ sai_attribute_t *attr_list);

/**
 * @brief Enum defining Flex Ethernet Group Event.
 */
typedef enum _sai_flexe_group_event_type_t
{
    /** C RX Change */
    SAI_FLEXE_GROUP_EVENT_TYPE_C_RX_CHANGE,

    /** CA RX Change */
    SAI_FLEXE_GROUP_EVENT_TYPE_CA_RX_CHANGE,

    /** CR RX Done */
    SAI_FLEXE_GROUP_EVENT_TYPE_CR_RX_DONE,

    /** CA RX Timeout */
    SAI_FLEXE_GROUP_EVENT_TYPE_CA_RX_TIMEOUT,

    /** Flex Ethernet Calendar Negotiation OK */
    SAI_FLEXE_GROUP_EVENT_TYPE_CALENDAR_NEG_OK,

    /** Flex Ethernet TX Calendar Negotiation OK */
    SAI_FLEXE_GROUP_EVENT_TYPE_TX_SWITCH_OK,

    /** Flex Ethernet RX Calendar Negotiation OK */
    SAI_FLEXE_GROUP_EVENT_TYPE_RX_SWITCH_OK

} sai_flexe_group_event_type_t;

/**
 * @brief Notification data format received from SAI Flex Ethernet Group event callback
 */
typedef struct _sai_flexe_group_notification_data_t
{
    /**
     * @brief Flex Ethernet Group ID
     *
     * @objects SAI_OBJECT_TYPE_FLEXE_GROUP
     */
    sai_object_id_t flexe_group_id;

    /**
     * @brief PHY Port ID
     *
     * @objects SAI_OBJECT_TYPE_PORT
     */
    sai_object_id_t phy_port_id;

    /** Flex Ethernet Group event */
    sai_flexe_group_event_type_t event;

    /** OH Flag C */
    uint32_t oh_flag_c;

    /** OH Flag CR */
    uint32_t oh_flag_cr;

    /** OH Flag CA */
    uint32_t oh_flag_ca;

} sai_flexe_group_notification_data_t;

/**
 * @brief Flex Ethernet Group event notification
 *
 * @count data[count]
 *
 * @param[in] count Number of notifications
 * @param[in] data Array of Flex Ethernet Group event status
 */
typedef void (*sai_flexe_group_event_notification_fn)(
        _In_ uint32_t count,
        _In_ const sai_flexe_group_notification_data_t *data);

/**
 * @brief Enum defining Flex Ethernet Group State event with clear.
 */
typedef enum _sai_flexe_group_state_event_type_t
{
    /** Calendar Mismatch */
    SAI_FLEXE_GROUP_STATE_EVENT_TYPE_CALENDAR_MISMATCH,

    /** Group Number Mismatch */
    SAI_FLEXE_GROUP_STATE_EVENT_TYPE_GRP_NUM_MISMATCH,

    /** Calendar Map Mismatch */
    SAI_FLEXE_GROUP_STATE_EVENT_TYPE_CALENDAR_MAP_MISMATCH,

    /** Instance Number Mismatch */
    SAI_FLEXE_GROUP_STATE_EVENT_TYPE_INSTANCE_NUM_MISMATCH,

    /** PHY Number Mismatch */
    SAI_FLEXE_GROUP_STATE_EVENT_TYPE_PHY_NUM_MISMATCH,

    /** Group Skew Over */
    SAI_FLEXE_GROUP_STATE_EVENT_TYPE_GROUP_SKEW_OVER,

    /** PHY Skew Over */
    SAI_FLEXE_GROUP_STATE_EVENT_TYPE_PHY_SKEW_OVER,

    /** Flex Ethernet loss of frame */
    SAI_FLEXE_GROUP_STATE_EVENT_TYPE_LOF,

    /** Flex Ethernet loss of multi-frame */
    SAI_FLEXE_GROUP_STATE_EVENT_TYPE_LOMF,

    /** Flex Ethernet OH FCS Error */
    SAI_FLEXE_GROUP_STATE_EVENT_TYPE_FCS_ERROR,

    /** Remote PHY Fault */
    SAI_FLEXE_GROUP_STATE_EVENT_TYPE_REMOTE_PHY_FAULT,

} sai_flexe_group_state_event_type_t;

/**
 * @brief Notification data format received from SAI Flex Ethernet Group event callback with state
 */
typedef struct _sai_flexe_group_state_notification_data_t
{
    /**
     * @brief Flex Ethernet Group ID
     *
     * @objects SAI_OBJECT_TYPE_FLEXE_GROUP
     */
    sai_object_id_t flexe_group_id;

    /**
     * @brief PHY Port ID
     *
     * @objects SAI_OBJECT_TYPE_PORT
     */
    sai_object_id_t phy_port_id;

    /** Flex Ethernet Instance Number */
    uint32_t instance_num;

    /** Flex Ethernet Group event */
    sai_flexe_group_state_event_type_t event;

    /** Event State: Occur or Clear */
    uint32_t event_state;

    /** OH Flag C */
    uint32_t oh_flag_c;

    /** OH Flag CR */
    uint32_t oh_flag_cr;

    /** OH Flag CA */
    uint32_t oh_flag_ca;

} sai_flexe_group_state_notification_data_t;

/**
 * @brief Flex Ethernet Group event state change notification
 *
 * @count data[count]
 *
 * @param[in] count Number of notifications
 * @param[in] data Array of Flex Ethernet Group event state change status
 */
typedef void (*sai_flexe_group_event_state_change_notification_fn)(
        _In_ uint32_t count,
        _In_ const sai_flexe_group_state_notification_data_t *data);

/**
 * @brief Flex Ethernet methods table retrieved with sai_api_query()
 */
typedef struct _sai_flexe_api_t
{
    sai_create_flexe_group_fn                        create_flexe_group;
    sai_remove_flexe_group_fn                        remove_flexe_group;
    sai_set_flexe_group_attribute_fn                 set_flexe_group_attribute;
    sai_get_flexe_group_attribute_fn                 get_flexe_group_attribute;
    sai_create_flexe_slot_fn                         create_flexe_slot;
    sai_remove_flexe_slot_fn                         remove_flexe_slot;
    sai_set_flexe_slot_attribute_fn                  set_flexe_slot_attribute;
    sai_get_flexe_slot_attribute_fn                  get_flexe_slot_attribute;
    sai_create_flexe_client_fn                       create_flexe_client;
    sai_remove_flexe_client_fn                       remove_flexe_client;
    sai_set_flexe_client_attribute_fn                set_flexe_client_attribute;
    sai_get_flexe_client_attribute_fn                get_flexe_client_attribute;
    sai_create_flexe_client_cross_connect_fn         create_flexe_client_cross_connect;
    sai_remove_flexe_client_cross_connect_fn         remove_flexe_client_cross_connect;
    sai_set_flexe_client_cross_connect_attribute_fn  set_flexe_client_cross_connect_attribute;
    sai_get_flexe_client_cross_connect_attribute_fn  get_flexe_client_cross_connect_attribute;
} sai_flexe_api_t;

/**
 * @}
 */
#endif /** __SAIEXPERIMENTALFLEXE_H_ */
