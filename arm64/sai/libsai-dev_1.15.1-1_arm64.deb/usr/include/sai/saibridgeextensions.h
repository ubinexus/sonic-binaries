/**
 * Copyright (c) 2014 Microsoft Open Technologies, Inc.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABILITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 *    Microsoft would like to thank the following companies for their review and
 *    assistance with these files: Intel Corporation, Mellanox Technologies Ltd,
 *    Dell Products, L.P., Facebook, Inc., Marvell International Ltd.
 *
 * @file    saibridgeextensions.h
 *
 * @brief   This module defines SAI Bridge extensions
 */

#ifndef __SAIBRIDGEEXTENSIONS_H_
#define __SAIBRIDGEEXTENSIONS_H_

#include <sai.h>

/**
 * @brief Attribute data for #SAI_BRIDGE_PORT_ATTR_TYPE extension
 *
 * @flags free
 */
typedef enum _sai_bridge_port_type_extensions_t
{
    SAI_BRIDGE_PORT_TYPE_EXTENSIONS_START = SAI_BRIDGE_PORT_TYPE_TUNNEL,

    /** Bridge Fast Reroute port */
    SAI_BRIDGE_PORT_TYPE_FRR,

    /** Bridge Load Balance port */
    SAI_BRIDGE_PORT_TYPE_LB,

    /** Bridge Double Vlan port */
    SAI_BRIDGE_PORT_TYPE_DOUBLE_VLAN_SUB_PORT,

    SAI_BRIDGE_PORT_TYPE_EXTENSIONS_END

} sai_bridge_port_type_extensions_t;

/**
 * @brief Bridge port outgoing service vlan cos mode extensions
 */
typedef enum _sai_bridge_port_outgoing_service_vlan_cos_mode_t
{
    /** Keep mode */
    SAI_BRIDGE_PORT_OUTGOING_SERVICE_VLAN_COS_MODE_KEEP,

    /** Map mode */
    SAI_BRIDGE_PORT_OUTGOING_SERVICE_VLAN_COS_MODE_MAP,

    /** Assign mode */
    SAI_BRIDGE_PORT_OUTGOING_SERVICE_VLAN_COS_MODE_ASSIGN,

} sai_bridge_port_outgoing_service_vlan_cos_mode_t;

/**
 * @brief SAI attributes for Bridge Port extensions
 *
 * @flags free
 */
typedef enum _sai_bridge_port_attr_extensions_t
{
    SAI_BRIDGE_PORT_ATTR_EXTENSIONS_RANGE_START = SAI_BRIDGE_PORT_ATTR_EXTENSIONS_RANGE_BASE,

    /**
     * @brief Cross connect bridge port
     *
     * @type sai_object_id_t
     * @flags CREATE_AND_SET
     * @objects SAI_OBJECT_TYPE_BRIDGE_PORT
     * @allownull true
     * @default SAI_NULL_OBJECT_ID
     */
    SAI_BRIDGE_PORT_ATTR_CROSS_CONNECT_BRIDGE_PORT = SAI_BRIDGE_PORT_ATTR_EXTENSIONS_RANGE_START,

    /**
     * @brief Enable OAM for sub port
     *
     * for Virtual Private LAN Service/Virtual Private Wire Service OAM
     *
     * @type bool
     * @flags CREATE_AND_SET
     * @default false
     * @validonly SAI_BRIDGE_PORT_ATTR_TYPE == SAI_BRIDGE_PORT_TYPE_SUB_PORT or SAI_BRIDGE_PORT_ATTR_TYPE == SAI_BRIDGE_PORT_TYPE_TUNNEL
     */
    SAI_BRIDGE_PORT_ATTR_SUB_TUNNEL_PORT_OAM_ENABLE,

    /**
     * @brief Fast Reroute nexthop group object ID
     *
     * for Virtual Private LAN Service Fast Reroute Decapsulation
     *
     * @type sai_object_id_t
     * @flags MANDATORY_ON_CREATE | CREATE_ONLY
     * @objects SAI_OBJECT_TYPE_NEXT_HOP_GROUP
     * @condition SAI_BRIDGE_PORT_ATTR_TYPE == SAI_BRIDGE_PORT_TYPE_FRR
     */
    SAI_BRIDGE_PORT_ATTR_FRR_NHP_GRP,

    /**
     * @brief Load Balance nexthop group object ID
     *
     * for Virtual Private LAN Service Load Balance Decapsulation
     *
     * @type sai_object_id_t
     * @flags MANDATORY_ON_CREATE | CREATE_ONLY
     * @objects SAI_OBJECT_TYPE_NEXT_HOP_GROUP
     * @condition SAI_BRIDGE_PORT_ATTR_TYPE == SAI_BRIDGE_PORT_TYPE_LB
     */
    SAI_BRIDGE_PORT_ATTR_LB_NHP_GRP,

    /**
     * @brief Policer id for sub port/tunnel port
     *
     * for Virtual Private LAN Service/Virtual Private Wire Service
     * set to NULL means disable policer on bridge port
     *
     * @type sai_object_id_t
     * @flags CREATE_AND_SET
     * @objects SAI_OBJECT_TYPE_POLICER
     * @allownull true
     * @default SAI_NULL_OBJECT_ID
     * @validonly SAI_BRIDGE_PORT_ATTR_TYPE == SAI_BRIDGE_PORT_TYPE_SUB_PORT or SAI_BRIDGE_PORT_ATTR_TYPE == SAI_BRIDGE_PORT_TYPE_TUNNEL
     */
    SAI_BRIDGE_PORT_ATTR_SUB_TUNNEL_PORT_POLICER_ID,

    /**
     * @brief Service id for sub port/tunnel port
     *
     * used for H-QOS, set to service schedule group service id
     * set to 0 means disable H-QOS on bridge sub port/tunnel port
     *
     * @type sai_uint16_t
     * @flags CREATE_AND_SET
     * @isvlan false
     * @default 0
     * @validonly SAI_BRIDGE_PORT_ATTR_TYPE == SAI_BRIDGE_PORT_TYPE_SUB_PORT or SAI_BRIDGE_PORT_ATTR_TYPE == SAI_BRIDGE_PORT_TYPE_TUNNEL
     */
    SAI_BRIDGE_PORT_ATTR_SUB_TUNNEL_PORT_SERVICE_ID,

    /**
     * @brief Service id direction
     *
     * used for H-QOS, set to service schedule group service id direction
     * set to 0 means ingress, set to 1 means egress
     * valid when SAI_BRIDGE_PORT_ATTR_SUB_TUNNEL_PORT_SERVICE_ID is not 0
     *
     * @type sai_uint16_t
     * @flags CREATE_AND_SET
     * @isvlan false
     * @default 0
     */
    SAI_BRIDGE_PORT_ATTR_SUB_TUNNEL_PORT_SERVICE_ID_DIRECTION,

    /**
     * @brief Outgoing Service Vlan
     *
     * @type sai_uint16_t
     * @flags CREATE_ONLY
     * @isvlan true
     * @default 0
     * @validonly SAI_BRIDGE_PORT_ATTR_TYPE == SAI_BRIDGE_PORT_TYPE_SUB_PORT or SAI_BRIDGE_PORT_ATTR_TYPE == SAI_BRIDGE_PORT_TYPE_DOUBLE_VLAN_SUB_PORT
     */
    SAI_BRIDGE_PORT_ATTR_OUTGOING_SERVICE_VLAN_ID,

    /**
     * @brief Outgoing Service Vlan Class of Service mode
     *
     * @type sai_bridge_port_outgoing_service_vlan_cos_mode_t
     * @flags CREATE_ONLY
     * @default SAI_BRIDGE_PORT_OUTGOING_SERVICE_VLAN_COS_MODE_KEEP
     * @validonly SAI_BRIDGE_PORT_ATTR_TYPE == SAI_BRIDGE_PORT_TYPE_SUB_PORT or SAI_BRIDGE_PORT_ATTR_TYPE == SAI_BRIDGE_PORT_TYPE_DOUBLE_VLAN_SUB_PORT
     */
    SAI_BRIDGE_PORT_ATTR_OUTGOING_SERVICE_VLAN_COS_MODE,

    /**
     * @brief Outgoing Service Vlan Class of Service
     *
     * Valid when SAI_BRIDGE_PORT_ATTR_OUTGOING_SERVICE_VLAN_COS_MODE == SAI_BRIDGE_PORT_OUTGOING_SERVICE_VLAN_COS_MODE_ASSIGN
     *
     * @type sai_uint8_t
     * @flags CREATE_ONLY
     * @default 0
     */
    SAI_BRIDGE_PORT_ATTR_OUTGOING_SERVICE_VLAN_COS,

    /**
     * @brief Customer Vlan for forwarding instance mapping
     *
     * @type sai_uint16_t
     * @flags MANDATORY_ON_CREATE | CREATE_ONLY
     * @isvlan true
     * @condition SAI_BRIDGE_PORT_ATTR_TYPE == SAI_BRIDGE_PORT_TYPE_DOUBLE_VLAN_SUB_PORT
     */
    SAI_BRIDGE_PORT_ATTR_CUSTOMER_VLAN_ID,

    /**
     * @brief Need flood in bridge instance
     *
     * @type bool
     * @flags CREATE_AND_SET
     * @default true
     * @validonly SAI_BRIDGE_PORT_ATTR_TYPE == SAI_BRIDGE_PORT_TYPE_SUB_PORT or SAI_BRIDGE_PORT_ATTR_TYPE == SAI_BRIDGE_PORT_TYPE_DOUBLE_VLAN_SUB_PORT or SAI_BRIDGE_PORT_ATTR_TYPE == SAI_BRIDGE_PORT_TYPE_TUNNEL or SAI_BRIDGE_PORT_ATTR_TYPE == SAI_BRIDGE_PORT_TYPE_FRR
     */
    SAI_BRIDGE_PORT_ATTR_NEED_FLOOD,

    /**
     * @brief Sub port traffic class assigned valid
     *
     * @type bool
     * @flags CREATE_AND_SET
     * @default false
     */
    SAI_BRIDGE_PORT_ATTR_SUB_PORT_QOS_TC_VALID,

    /**
     * @brief Sub port traffic class assigned
     *
     * @type sai_uint8_t
     * @flags CREATE_AND_SET
     * @default 0
     * @validonly SAI_BRIDGE_PORT_ATTR_SUB_PORT_QOS_TC_VALID == true
     */
    SAI_BRIDGE_PORT_ATTR_SUB_PORT_QOS_TC,

    /**
     * @brief Sub port color assigned valid
     *
     * @type bool
     * @flags CREATE_AND_SET
     * @default false
     */
    SAI_BRIDGE_PORT_ATTR_SUB_PORT_QOS_PACKET_COLOR_VALID,

    /**
     * @brief Sub port color assigned
     *
     * @type sai_packet_color_t
     * @flags CREATE_AND_SET
     * @default SAI_PACKET_COLOR_GREEN
     * @validonly SAI_BRIDGE_PORT_ATTR_SUB_PORT_QOS_PACKET_COLOR_VALID == true
     */
    SAI_BRIDGE_PORT_ATTR_SUB_PORT_QOS_PACKET_COLOR,

    /**
     * @brief Enable DOT1P -> TC MAP on bridge port
     *
     * Map id = #SAI_NULL_OBJECT_ID to disable map on bridge port.
     * To enable/disable trust Dot1p, map ID should be added/removed on bridge port.
     * Overrides SAI_SWITCH_ATTR_QOS_DOT1P_TO_TC_MAP and SAI_PORT_ATTR_QOS_DOT1P_TO_TC_MAP
     *
     * @type sai_object_id_t
     * @flags CREATE_AND_SET
     * @objects SAI_OBJECT_TYPE_QOS_MAP
     * @allownull true
     * @default SAI_NULL_OBJECT_ID
     */
    SAI_BRIDGE_PORT_ATTR_QOS_DOT1P_TO_TC_MAP,

    /**
     * @brief Enable DOT1P -> COLOR MAP on bridge port
     *
     * Map id = #SAI_NULL_OBJECT_ID to disable map on bridge port.
     * To enable/disable trust Dot1p, map ID should be added/removed on bridge port.
     * Overrides SAI_SWITCH_ATTR_QOS_DOT1P_TO_COLOR_MAP and SAI_PORT_ATTR_QOS_DOT1P_TO_COLOR_MAP
     *
     * @type sai_object_id_t
     * @flags CREATE_AND_SET
     * @objects SAI_OBJECT_TYPE_QOS_MAP
     * @allownull true
     * @default SAI_NULL_OBJECT_ID
     */
    SAI_BRIDGE_PORT_ATTR_QOS_DOT1P_TO_COLOR_MAP,

    /**
     * @brief Enable DSCP -> TC MAP on bridge port
     *
     * Map id = #SAI_NULL_OBJECT_ID to disable map on bridge port.
     * To enable/disable trust DSCP, map ID should be added/removed on bridge port.
     * Overrides SAI_SWITCH_ATTR_QOS_DSCP_TO_TC_MAP and SAI_PORT_ATTR_QOS_DSCP_TO_TC_MAP
     *
     * @type sai_object_id_t
     * @flags CREATE_AND_SET
     * @objects SAI_OBJECT_TYPE_QOS_MAP
     * @allownull true
     * @default SAI_NULL_OBJECT_ID
     */
    SAI_BRIDGE_PORT_ATTR_QOS_DSCP_TO_TC_MAP,

    /**
     * @brief Enable DSCP -> COLOR MAP on bridge port
     *
     * Map id = #SAI_NULL_OBJECT_ID to disable map on bridge port.
     * To enable/disable trust DSCP, map ID should be added/removed on bridge port.
     * Overrides SAI_SWITCH_ATTR_QOS_DSCP_TO_COLOR_MAP and SAI_PORT_ATTR_QOS_DSCP_TO_COLOR_MAP
     *
     * @type sai_object_id_t
     * @flags CREATE_AND_SET
     * @objects SAI_OBJECT_TYPE_QOS_MAP
     * @allownull true
     * @default SAI_NULL_OBJECT_ID
     */
    SAI_BRIDGE_PORT_ATTR_QOS_DSCP_TO_COLOR_MAP,

    /**
     * @brief Enable port-security on bridge port
     *
     * @type bool
     * @flags CREATE_AND_SET
     * @default false
     */
    SAI_BRIDGE_PORT_ATTR_PORT_SECURITY,

    /**
     * @brief Associated fast switchover tunnel id
     *
     * @type sai_object_id_t
     * @flags CREATE_ONLY
     * @objects SAI_OBJECT_TYPE_TUNNEL
     * @allownull true
     * @default SAI_NULL_OBJECT_ID
     * @validonly SAI_BRIDGE_PORT_ATTR_TYPE == SAI_BRIDGE_PORT_TYPE_SUB_PORT or SAI_BRIDGE_PORT_ATTR_TYPE == SAI_BRIDGE_PORT_TYPE_DOUBLE_VLAN_SUB_PORT or SAI_BRIDGE_PORT_ATTR_TYPE == SAI_BRIDGE_PORT_TYPE_PORT
     */
    SAI_BRIDGE_PORT_ATTR_FAST_SWITCHOVER_TUNNEL,

    /**
     * @brief Trigger a switch-over from primary port to backup tunnel
     *
     * @type bool
     * @flags CREATE_AND_SET
     * @default false
     * @validonly SAI_BRIDGE_PORT_ATTR_TYPE == SAI_BRIDGE_PORT_TYPE_SUB_PORT or SAI_BRIDGE_PORT_ATTR_TYPE == SAI_BRIDGE_PORT_TYPE_DOUBLE_VLAN_SUB_PORT or SAI_BRIDGE_PORT_ATTR_TYPE == SAI_BRIDGE_PORT_TYPE_PORT
     */
    SAI_BRIDGE_PORT_ATTR_SET_SWITCHOVER,

    /**
     * @brief Bridge port for MPLS application
     *
     * @type bool
     * @flags CREATE_ONLY
     * @default false
     * @validonly SAI_BRIDGE_PORT_ATTR_TYPE == SAI_BRIDGE_PORT_TYPE_SUB_PORT or SAI_BRIDGE_PORT_ATTR_TYPE == SAI_BRIDGE_PORT_TYPE_DOUBLE_VLAN_SUB_PORT or SAI_BRIDGE_PORT_ATTR_TYPE == SAI_BRIDGE_PORT_TYPE_PORT
     */
    SAI_BRIDGE_PORT_ATTR_IS_MPLS_ACCESS_PORT,

    SAI_BRIDGE_PORT_ATTR_EXTENSIONS_RANGE_END

} sai_bridge_port_attr_extensions_t;

/**
 * @brief Attribute data for #SAI_BRIDGE_ATTR_TYPE extensions
 *
 * @flags free
 */
typedef enum _sai_bridge_type_extensions_t
{
    SAI_BRIDGE_TYPE_EXTENSIONS_START = SAI_BRIDGE_TYPE_1D,

    /** Cross connect without bridge table */
    SAI_BRIDGE_TYPE_CROSS_CONNECT,

    SAI_BRIDGE_TYPE_EXTENSIONS_END

} sai_bridge_type_extensions_t;

#endif /** __SAIBRIDGEEXTENSIONS_H_ */
